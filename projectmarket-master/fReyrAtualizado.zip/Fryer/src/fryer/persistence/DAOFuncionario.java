package fryer.persistence;

import fryer.model.Funcionario;

public class DAOFuncionario extends DAO {

	public void cadastrar(Funcionario func) {
		entityManager.getTransaction().begin();
		entityManager.persist(func);
		entityManager.getTransaction().commit();
		entityManager.close(); 
	}
}
