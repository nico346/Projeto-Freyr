package freyr.persistence;

import freyr.model.Usuario;

public class IniciaUsuario {
	
	public static void main(String args[]) {
		Usuario u = new Usuario();
		u.setLogin("victor");
		u.setSenha("123456");
		
		DAOUsuario dao = new DAOUsuario();
		dao.cadastrar(u);
		
		//DAOFuncionario dao2 = new DAOFuncionario();
		//dao2.getLista();
	}
}
