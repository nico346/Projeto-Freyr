package freyr.persistence;



import freyr.model.Mensagem;

public class DAOMensagem extends DAO {

	public DAOMensagem(){
		super();
	}
	
	public void cadastrar(Mensagem m) {
		entityManager.getTransaction().begin(); // inicia uma transa��o
		entityManager.persist(m); // objeto a ser cadastrado
		entityManager.getTransaction().commit(); // executa o cadastro
		entityManager.close(); // fecha conex�o
	}
	
	
	
	
	
	
	
	
}
