package freyr.persistence;

import java.util.List;

import freyr.model.Usuario;

public class DAOUsuario extends DAO {
	
	@SuppressWarnings("rawtypes")
	public boolean login(String login, String senha){
		
		String sql = "from Usuario as u where u.login=:vLogin AND u.senha=:vSenha";
		
		javax.persistence.Query query = 
				entityManager.createQuery(sql);
		
		query.setParameter("vLogin", login);
		query.setParameter("vSenha",senha);
		
		
		List result = query.getResultList();
		
		if(result.size()>0)
			return true;
		else
			return false;
	
	}
	
	public void cadastrar(Usuario u) {
		entityManager.getTransaction().begin();
		entityManager.persist(u);
		entityManager.getTransaction().commit();
		entityManager.close(); 
	}
	
	
}
