package freyr.persistence;

import java.util.List;


import freyr.model.Funcionario;

public class DAOFuncionario extends DAO {

	public DAOFuncionario(){
		super();
	}
	
	public void cadastrar(Funcionario f) {
		entityManager.getTransaction().begin(); // inicia uma transa��o
		entityManager.persist(f); // objeto a ser cadastrado
		entityManager.getTransaction().commit(); // executa o cadastro
		entityManager.close(); // fecha conex�o
	}
	
	@SuppressWarnings("unchecked")
	public List<Funcionario> getLista(){
		return entityManager.createQuery("FROM Funcionario f").getResultList();
	}
	
public Funcionario visualiza(Integer id) {
		
		return entityManager.find(Funcionario.class, id);
	}

	public void atualizar(Funcionario funcionario) { 
		entityManager.getTransaction().begin();
		entityManager.merge(funcionario);
		entityManager.getTransaction().commit();
		entityManager.close();
		
	}
	
	
	
	
	
	
	
	
}
