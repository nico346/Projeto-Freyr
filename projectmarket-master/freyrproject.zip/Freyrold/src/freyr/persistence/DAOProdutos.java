package freyr.persistence;

import java.util.List;

import freyr.model.Produtos;

public class DAOProdutos extends DAO {

	public DAOProdutos(){
		super();
	}
	
	public void cadastrar(Produtos p) {
		entityManager.getTransaction().begin(); // inicia uma transa��o
		entityManager.persist(p); // objeto a ser cadastrado
		entityManager.getTransaction().commit(); // executa o cadastro
		entityManager.close(); // fecha conex�o
	}
	
	@SuppressWarnings("unchecked")
	public List<Produtos> getLista(){
		return entityManager.createQuery("FROM Produtos p").getResultList();
	}
	
public Produtos visualiza(Integer id) {
		
		return entityManager.find(Produtos.class, id);
	}

	public void atualizar(Produtos produtos) { 
		entityManager.getTransaction().begin();
		entityManager.merge(produtos);
		entityManager.getTransaction().commit();
		entityManager.close();
		
	}
	
	
	
	
	
	
	
	
}
