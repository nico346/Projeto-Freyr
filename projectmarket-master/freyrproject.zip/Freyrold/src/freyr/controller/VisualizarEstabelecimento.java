package freyr.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import freyr.model.Contato;
import freyr.model.Endereco;
import freyr.model.Estabelecimento;
import freyr.persistence.DAOEstabelecimento;

/**
 * Servlet implementation class VisualizarEstabelecimento
 */
@WebServlet("/VisualizarEstabelecimento")
public class VisualizarEstabelecimento extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Integer id = Integer.parseInt(request.getParameter("id"));
		
		
		DAOEstabelecimento dao = new DAOEstabelecimento();
		request.setAttribute("estabelecimento", dao.visualiza(id));
		request.getRequestDispatcher("listaestabelecimento.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Contato cont = new Contato();
		cont.setEmail(request.getParameter("email"));
		cont.setTelefone(request.getParameter("telefone"));
		
		Endereco end = new Endereco();
		end.setCep(request.getParameter("cep"));
		end.setEndereco(request.getParameter("endereco"));
		end.setBairro(request.getParameter("bairro"));
		end.setCidade(request.getParameter("cidade"));
		end.setEstado(request.getParameter("estado"));
		end.setNumero(request.getParameter("numero"));
		end.setPais(request.getParameter("pais"));
		end.setComplemento(request.getParameter("complemento"));
		
		Estabelecimento est = new Estabelecimento();
		est.setCnpj(request.getParameter("cnpj"));
		est.setNome(request.getParameter("nome"));
		est.setFilial(request.getParameter("filial"));
		est.setEndereco(end);
		est.setContato(cont);
	}

}
