package freyr.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import freyr.model.Contato;
import freyr.model.Endereco;
import freyr.model.Funcionario;
import freyr.persistence.DAOContato;
import freyr.persistence.DAOEndereco;
import freyr.persistence.DAOFuncionario;

/**
 * Servlet implementation class CadastraFuncionario
 */
@WebServlet("/CadastraFuncionario")
public class CadastraFuncionario extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try { 
			Endereco end = new Endereco();
		   	end.setEndereco(request.getParameter("endereco"));
		   	end.setNumero(request.getParameter("numero"));
		   	end.setBairro(request.getParameter("bairro"));
		   	end.setCidade(request.getParameter("cidade"));
		   	end.setEstado(request.getParameter("estado"));
		   	end.setPais(request.getParameter("pais"));
		   	end.setCep(request.getParameter("cep"));
		   	end.setComplemento(request.getParameter("complemento"));
			Contato cont = new Contato();
			cont.setTelefone(request.getParameter("telefone"));
			cont.setEmail(request.getParameter("email"));
			Funcionario func = new Funcionario();
			func.setNome(request.getParameter("nome"));
			func.setCpf(request.getParameter("cpf"));
			func.setSexo(request.getParameter("sexo"));
			func.setPaisOrigem(request.getParameter("paisOrigem"));
			func.setEndereco(end);
			func.setContato(cont);
			
			//DAO
			DAOContato daoc = new DAOContato();
			daoc.cadastrar(cont);
			DAOEndereco daoe = new DAOEndereco();
			daoe.cadastrar(end);
			DAOFuncionario dao = new DAOFuncionario();
			dao.cadastrar(func);
			request.setAttribute("servMensagem", "Cadastrado!");
			
		}catch (Exception e) { 
			request.setAttribute("servMensagem", "Erro!");
		}
		
		request.getRequestDispatcher("form-funcionario.jsp")
			.forward(request, response);
		
		
		
	}

}
