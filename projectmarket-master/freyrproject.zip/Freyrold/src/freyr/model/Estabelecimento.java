package freyr.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Estabelecimento implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private Integer idEstabelecimento;
	private String filial;
	private String nome;
	private String cnpj;
	
	@ManyToMany(mappedBy = "estabelecimento")
	private List<Funcionario> funcionario = new ArrayList<Funcionario>();
		
	@OneToOne
	@JoinColumn(name = "idEndereco")
	private Endereco endereco;
	
	@OneToOne
	@JoinColumn(name = "idContato")
	private Contato contato;
	
	@ManyToMany(mappedBy = "estabelecimento")
	private List<Produtos> produtos = new ArrayList<Produtos>();
	
	@OneToMany(mappedBy = "estabelecimento")
	private List<Reserva> reserva = new ArrayList<Reserva>();
	
	public Estabelecimento() {
		
	}
	
	
	
	public List<Reserva> getReserva() {
		return reserva;
	}



	public void setReserva(List<Reserva> reserva) {
		this.reserva = reserva;
	}



	public Integer getIdEstabelecimento() {
		return idEstabelecimento;
	}


	public void setIdEstabelecimento(Integer idEstabelecimento) {
		this.idEstabelecimento = idEstabelecimento;
	}


	public List<Produtos> getProdutos() {
		return produtos;
	}


	public void setProdutos(List<Produtos> produtos) {
		this.produtos = produtos;
	}


	public String getFilial() {
		return filial;
	}


	public void setFilial(String filial) {
		this.filial = filial;
	}


	public Endereco getEndereco() {
		return endereco;
	}


	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}


	public Contato getContato() {
		return contato;
	}


	public void setContato(Contato contato) {
		this.contato = contato;
	}


	public List<Funcionario> getFuncionario() {
		return funcionario;
	}


	public void setFuncionario(List<Funcionario> funcionario) {
		this.funcionario = funcionario;
	}


		public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	

}
